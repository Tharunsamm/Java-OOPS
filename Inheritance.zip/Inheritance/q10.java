class Employee {
    String name;
    String address;
    double salary;
    String jobTitle;

    Employee(String name, String address, double salary, String jobTitle) {
        this.name = name;
        this.address = address;
        this.salary = salary;
        this.jobTitle = jobTitle;
    }

    void calculateBonus() {
        System.out.println("Employee Bonus: " + (salary * 0.05));
    }

    void performanceReport() {
        System.out.println("Employee performance report");
    }

    void manageProject() {
        System.out.println("Employee is working on a project");
    }
}


class Manager extends Employee {

    Manager(String name, String address, double salary, String jobTitle) {
        super(name, address, salary, jobTitle);
    }

    @Override
    void calculateBonus() {
        System.out.println("Manager Bonus: " + (salary * 0.20));
    }

    @Override
    void performanceReport() {
        System.out.println("Manager performance is excellent");
    }

    @Override
    void manageProject() {
        System.out.println("Manager is managing the project");
    }
}


class Developer extends Employee {

    Developer(String name, String address, double salary, String jobTitle) {
        super(name, address, salary, jobTitle);
    }

    @Override
    void calculateBonus() {
        System.out.println("Developer Bonus: " + (salary * 0.15));
    }

    @Override
    void performanceReport() {
        System.out.println("Developer performance is good");
    }

    @Override
    void manageProject() {
        System.out.println("Developer is developing the project");
    }
}


class Programmer extends Employee {

    Programmer(String name, String address, double salary, String jobTitle) {
        super(name, address, salary, jobTitle);
    }

    @Override
    void calculateBonus() {
        System.out.println("Programmer Bonus: " + (salary * 0.10));
    }

    @Override
    void performanceReport() {
        System.out.println("Programmer performance is good");
    }

    @Override
    void manageProject() {
        System.out.println("Programmer is programming the project");
    }
}


public class q10 {
    public static void main(String[] args) {

        Manager m = new Manager(
                "John",
                "Chicago",
                90000,
                "Project Manager"
        );

        Developer d = new Developer(
                "David",
                "New York",
                80000,
                "Java Developer"
        );

        Programmer p = new Programmer(
                "Sam",
                "Dallas",
                70000,
                "Programmer"
        );

        m.calculateBonus();
        m.performanceReport();
        m.manageProject();

        System.out.println();

        d.calculateBonus();
        d.performanceReport();
        d.manageProject();

        System.out.println();

        p.calculateBonus();
        p.performanceReport();
        p.manageProject();
    }
}