import java.util.ArrayList;

class Movie {
    String title;
    String director;
    ArrayList<String> actors = new ArrayList<>();
    ArrayList<String> reviews = new ArrayList<>();

    Movie(String title, String director) {
        this.title = title;
        this.director = director;
    }

    void addActor(String actor) {
        actors.add(actor);
    }

    void addReview(String review) {
        reviews.add(review);
    }

    void displayReviews() {
        System.out.println("Reviews:");

        for (String review : reviews) {
            System.out.println(review);
        }
    }
}

public class q17 {
    public static void main(String[] args) {
        Movie m1 = new Movie("Movie One", "John Smith");

        m1.addActor("Actor A");
        m1.addActor("Actor B");

        m1.addReview("Great movie");
        m1.addReview("Very entertaining");

        m1.displayReviews();
    }
}