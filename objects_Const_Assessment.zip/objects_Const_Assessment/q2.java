class Dog {
    String name;
    String breed;

    // Constructor
    Dog(String name, String breed) {
        this.name = name;
        this.breed = breed;
    }

    // Setter method for name
    void setName(String name) {
        this.name = name;
    }

    // Setter method for breed
    void setBreed(String breed) {
        this.breed = breed;
    }

    // Method to display Dog details
    void display() {
        System.out.println("Name: " + name);
        System.out.println("Breed: " + breed);
    }
}

public class q2 {
    public static void main(String[] args) {

        // Creating two Dog objects using constructor
        Dog dog1 = new Dog("Max", "Labrador");
        Dog dog2 = new Dog("Rocky", "German Shepherd");

        // Modifying values using setter methods
        dog1.setName("Charlie");
        dog1.setBreed("Golden Retriever");

        dog2.setName("Bruno");
        dog2.setBreed("Husky");

        // Printing updated values
        dog1.display();
        dog2.display();
    }
}