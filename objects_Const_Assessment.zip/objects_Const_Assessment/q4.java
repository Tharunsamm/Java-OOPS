class Circle {

    double radius;

    // Constructor
    Circle(double radius) {
        this.radius = radius;
    }

    // Setter method to modify radius
    void setRadius(double radius) {
        this.radius = radius;
    }

    // Method to calculate area
    void calculateArea() {
        double area = Math.PI * radius * radius;
        System.out.println("Area: " + area);
    }

    // Method to calculate circumference
    void calculateCircumference() {
        double circumference = 2 * Math.PI * radius;
        System.out.println("Circumference: " + circumference);
    }
}

public class q4 {
    public static void main(String[] args) {

        // Creating Circle object
        Circle c1 = new Circle(5.0);

        // Modifying radius
        c1.setRadius(7.0);

        // Calculating area and circumference
        c1.calculateArea();
        c1.calculateCircumference();
    }
}