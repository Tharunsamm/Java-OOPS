import java.util.ArrayList;

class School {
    ArrayList<String> students = new ArrayList<>();
    ArrayList<String> teachers = new ArrayList<>();
    ArrayList<String> classes = new ArrayList<>();

    void addStudent(String student) {
        students.add(student);
    }

    void removeStudent(String student) {
        students.remove(student);
    }

    void addTeacher(String teacher) {
        teachers.add(teacher);
    }

    void removeTeacher(String teacher) {
        teachers.remove(teacher);
    }

    void createClass(String className) {
        classes.add(className);
    }

    void display() {
        System.out.println("Students: " + students);
        System.out.println("Teachers: " + teachers);
        System.out.println("Classes: " + classes);
    }
}

public class q14 {
    public static void main(String[] args) {
        School school = new School();

        school.addStudent("John");
        school.addTeacher("Mr. Smith");
        school.createClass("Java");

        school.display();
    }
}