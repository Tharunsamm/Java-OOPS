import java.time.LocalDate;
import java.time.Period;

class Employee {

    String name;
    double salary;
    LocalDate hireDate;

    // Constructor
    Employee(String name, double salary, LocalDate hireDate) {
        this.name = name;
        this.salary = salary;
        this.hireDate = hireDate;
    }

    // Method to calculate years of service
    int calculateYearsOfService() {
        LocalDate currentDate = LocalDate.now();

        Period period = Period.between(hireDate, currentDate);

        return period.getYears();
    }

    // Display employee details
    void display() {
        System.out.println("Name: " + name);
        System.out.println("Salary: $" + salary);
        System.out.println("Hire Date: " + hireDate);
        System.out.println("Years of Service: " + calculateYearsOfService());
    }
}

public class q9 {

    public static void main(String[] args) {

        Employee e1 = new Employee(
            "John",
            60000,
            LocalDate.of(2020, 5, 10)
        );

        e1.display();
    }
}