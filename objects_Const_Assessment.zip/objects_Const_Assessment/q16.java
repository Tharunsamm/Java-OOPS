abstract class Shape {

    abstract double calculateArea();

    abstract double calculatePerimeter();
}

class Rectangle extends Shape {

    double length;
    double width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    double calculateArea() {
        return length * width;
    }

    double calculatePerimeter() {
        return 2 * (length + width);
    }
}

class Circle extends Shape {

    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    double calculateArea() {
        return Math.PI * radius * radius;
    }

    double calculatePerimeter() {
        return 2 * Math.PI * radius;
    }
}

class Triangle extends Shape {

    double a;
    double b;
    double c;

    Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    double calculateArea() {
        double s = (a + b + c) / 2;

        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }

    double calculatePerimeter() {
        return a + b + c;
    }
}

public class q16 {
    public static void main(String[] args) {

        Rectangle r = new Rectangle(10, 5);
        Circle c = new Circle(7);
        Triangle t = new Triangle(3, 4, 5);

        System.out.println("Rectangle Area: " + r.calculateArea());
        System.out.println("Circle Area: " + c.calculateArea());
        System.out.println("Triangle Area: " + t.calculateArea());
    }
}