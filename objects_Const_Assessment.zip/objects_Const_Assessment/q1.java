class Person{
    String name;
    int age;

    public Person(String n, int a){
        this.name = n;
        this.age = a;
    }

}

public class q1{
    public static void main(String[]args){
        Person P1 = new Person("Tharun", 23);
        Person P2 = new Person("Alice", 25);
        System.out.println(P1.name + " is " + P1.age + " years old.");
        System.out.println(P2.name + " is " + P2.age + " years old.");
    }


}
