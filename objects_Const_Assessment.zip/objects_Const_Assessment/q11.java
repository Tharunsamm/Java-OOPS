import java.util.ArrayList;

class Library {
    ArrayList<String> books = new ArrayList<>();

    void addBook(String book) {
        books.add(book);
    }

    void removeBook(String book) {
        books.remove(book);
    }

    void displayBooks() {
        System.out.println("Books: " + books);
    }
}

public class q11 {
    public static void main(String[] args) {
        Library library = new Library();
        
        library.addBook("Java Basics");
        library.addBook("Python Basics");

        library.removeBook("Python Basics");

        library.displayBooks();
        
    }
}