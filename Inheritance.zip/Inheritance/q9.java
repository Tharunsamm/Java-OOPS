class Vehicle {
    String make;
    String model;
    int year;
    String fuelType;

    Vehicle(String make, String model, int year, String fuelType) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.fuelType = fuelType;
    }

    void fuelEfficiency() {
        System.out.println("Calculating vehicle fuel efficiency");
    }

    void distanceTraveled() {
        System.out.println("Calculating distance traveled");
    }

    void maximumSpeed() {
        System.out.println("Calculating maximum speed");
    }
}


class Car extends Vehicle {

    Car(String make, String model, int year, String fuelType) {
        super(make, model, year, fuelType);
    }

    @Override
    void fuelEfficiency() {
        System.out.println("Car Fuel Efficiency: 30 MPG");
    }

    @Override
    void distanceTraveled() {
        System.out.println("Car Distance Traveled: 400 miles");
    }

    @Override
    void maximumSpeed() {
        System.out.println("Car Maximum Speed: 150 MPH");
    }
}


class Truck extends Vehicle {

    Truck(String make, String model, int year, String fuelType) {
        super(make, model, year, fuelType);
    }

    @Override
    void fuelEfficiency() {
        System.out.println("Truck Fuel Efficiency: 18 MPG");
    }

    @Override
    void distanceTraveled() {
        System.out.println("Truck Distance Traveled: 300 miles");
    }

    @Override
    void maximumSpeed() {
        System.out.println("Truck Maximum Speed: 110 MPH");
    }
}


class Motorcycle extends Vehicle {

    Motorcycle(String make, String model, int year, String fuelType) {
        super(make, model, year, fuelType);
    }

    @Override
    void fuelEfficiency() {
        System.out.println("Motorcycle Fuel Efficiency: 50 MPG");
    }

    @Override
    void distanceTraveled() {
        System.out.println("Motorcycle Distance Traveled: 250 miles");
    }

    @Override
    void maximumSpeed() {
        System.out.println("Motorcycle Maximum Speed: 180 MPH");
    }
}


public class q9 {
    public static void main(String[] args) {

        Car c = new Car("Toyota", "Camry", 2024, "Gasoline");
        Truck t = new Truck("Ford", "F-150", 2023, "Diesel");
        Motorcycle m = new Motorcycle("Yamaha", "R1", 2024, "Gasoline");

        c.fuelEfficiency();
        c.distanceTraveled();
        c.maximumSpeed();

        System.out.println();

        t.fuelEfficiency();
        t.distanceTraveled();
        t.maximumSpeed();

        System.out.println();

        m.fuelEfficiency();
        m.distanceTraveled();
        m.maximumSpeed();
    }
}