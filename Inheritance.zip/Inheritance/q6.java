class Animal{
    void move(){
        System.out.println("Animal moves");
    }
}
class Cheetah extends Animal{
    void move(){
        System.out.println("Cheetah moves fast");
    }
}
public class q6{
    public static void main(String[] args){
            Animal a = new Animal();
            Cheetah c = new Cheetah();
            a.move();
            c.move();
        
    }
}