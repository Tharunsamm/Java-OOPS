class Employee {

    void work() {
        System.out.println("Employee is working");
    }

    void getSalary() {
        System.out.println("Employee gets salary");
    }
}

class HRManager extends Employee {

    @Override
    void work() {
        System.out.println("HR Manager is managing employees");
    }

    void addEmployee() {
        System.out.println("HR Manager added a new employee");
    }
}

public class q4 {
    public static void main(String[] args) {

        Employee e = new Employee();
        HRManager hr = new HRManager();

        e.work();
        e.getSalary();

        hr.work();
        hr.getSalary();
        hr.addEmployee();
    }
}