import java.util.ArrayList;

class Book {

    String title;
    String author;
    String ISBN;

    // Constructor
    Book(String title, String author, String ISBN) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
    }
}

class BookCollection {

    ArrayList<Book> books = new ArrayList<>();

    // Method to add a book
    void addBook(Book book) {
        books.add(book);
    }

    // Method to remove a book
    void removeBook(Book book) {
        books.remove(book);
    }

    // Method to display all books
    void displayBooks() {

        for (Book book : books) {
            System.out.println("Title: " + book.title);
            System.out.println("Author: " + book.author);
            System.out.println("ISBN: " + book.ISBN);
            System.out.println();
        }
    }
}

public class q5 {

    public static void main(String[] args) {

        // Creating Book objects
        Book b1 = new Book("Harry Potter", "J.K. Rowling", "101");
        Book b2 = new Book("The Hobbit", "J.R.R. Tolkien", "102");

        // Creating collection
        BookCollection collection = new BookCollection();

        // Adding books
        collection.addBook(b1);
        collection.addBook(b2);

        System.out.println("Books after adding:");
        collection.displayBooks();

        // Removing one book
        collection.removeBook(b1);

        System.out.println("Books after removing:");
        collection.displayBooks();
    }
}