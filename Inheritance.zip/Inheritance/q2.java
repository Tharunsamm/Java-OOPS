class Vehicle{
    void Drive(){
        System.out.println("Vehicle is driving");
    }
}
class car extends Vehicle{
    void Drive(){
        System.out.println("Repairing car");
    }
}
public class q2{
    public static void main(String[] args){
            Vehicle v = new Vehicle();
            car c = new car();
            v.Drive();
            c.Drive();
        
    }
}