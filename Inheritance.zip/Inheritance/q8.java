class shape {
    void getperimeter() {
        System.out.println("Area of shape");
    }
    void getArea() {
        System.out.println("Area of shape");
    }
}
class Circle extends shape {
    double radius;
    Circle(double radius) {
        this.radius = radius;
    }
    @Override
    void getperimeter() {
        System.out.println("Perimeter of Circle: " + (2 * Math.PI * radius));
    }
    @Override
    void getArea() {
        System.out.println("Area of Circle: " + (Math.PI * radius * radius));
    }
}
public class q8 {
    public static void main(String[] args) {
        Circle c = new Circle(5);
        c.getperimeter();
        c.getArea();
    }
}