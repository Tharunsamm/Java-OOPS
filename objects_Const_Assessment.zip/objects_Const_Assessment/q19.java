import java.util.ArrayList;

class TravelBooking {

    ArrayList<String> reservations = new ArrayList<>();

    void searchFlight(String destination) {
        System.out.println("Searching flights to " + destination);
    }

    void searchHotel(String location) {
        System.out.println("Searching hotels in " + location);
    }

    void bookReservation(String reservation) {
        reservations.add(reservation);

        System.out.println("Booked: " + reservation);
    }

    void cancelReservation(String reservation) {
        reservations.remove(reservation);

        System.out.println("Cancelled: " + reservation);
    }

    void displayReservations() {
        System.out.println("Reservations: " + reservations);
    }
}

public class q19 {
    public static void main(String[] args) {

        TravelBooking booking = new TravelBooking();

        booking.searchFlight("Chicago");
        booking.searchHotel("Chicago");

        booking.bookReservation("Flight AA101");
        booking.bookReservation("Hilton Hotel");

        booking.displayReservations();

        booking.cancelReservation("Flight AA101");

        booking.displayReservations();
    }
}