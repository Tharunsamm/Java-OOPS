class Rectangle{
    int width;
    double height;

    // (P = 2(l + w)
    double perimeter() {
        return 2 * (width + height);
    }

    // Area = l * w
    double Area() {
        return width * height;
    }
}

public class q3{
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle();
        r1.width = 5;
        r1.height = 10.0;

        System.out.println("Perimeter of rectangle: " + r1.perimeter());
        System.out.println("Area of rectangle: " + r1.Area());
}

}