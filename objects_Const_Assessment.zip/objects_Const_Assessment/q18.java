import java.util.ArrayList;

class Restaurant {

    ArrayList<String> menuItems = new ArrayList<>();
    ArrayList<Double> prices = new ArrayList<>();
    ArrayList<Integer> ratings = new ArrayList<>();

    void addItem(String item, double price) {
        menuItems.add(item);
        prices.add(price);
    }

    void removeItem(String item) {
        int index = menuItems.indexOf(item);

        if (index != -1) {
            menuItems.remove(index);
            prices.remove(index);
        }
    }

    void addRating(int rating) {
        ratings.add(rating);
    }

    double calculateAverageRating() {
        int sum = 0;

        for (int rating : ratings) {
            sum = sum + rating;
        }

        return (double) sum / ratings.size();
    }
}

public class q18 {
    public static void main(String[] args) {

        Restaurant restaurant = new Restaurant();

        restaurant.addItem("Burger", 10.99);
        restaurant.addItem("Pizza", 12.99);

        restaurant.addRating(5);
        restaurant.addRating(4);
        restaurant.addRating(3);

        System.out.println(
            "Average Rating: " + restaurant.calculateAverageRating()
        );
    }
}