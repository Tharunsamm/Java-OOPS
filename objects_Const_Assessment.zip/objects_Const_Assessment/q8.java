class TrafficLight {

    String color;
    int duration;

    // Constructor
    TrafficLight(String color, int duration) {
        this.color = color;
        this.duration = duration;
    }

    // Method to change the color
    void changeColor(String color) {
        this.color = color;
    }

    // Method to check if the light is red
    void checkRed() {
        if (color.equalsIgnoreCase("Red")) {
            System.out.println("Traffic light is Red");
        } else {
            System.out.println("Traffic light is not Red");
        }
    }

    // Method to check if the light is green
    void checkGreen() {
        if (color.equalsIgnoreCase("Green")) {
            System.out.println("Traffic light is Green");
        } else {
            System.out.println("Traffic light is not Green");
        }
    }

    // Display details
    void display() {
        System.out.println("Color: " + color);
        System.out.println("Duration: " + duration + " seconds");
    }
}

public class q8 {
    public static void main(String[] args) {

        // Creating TrafficLight object
        TrafficLight t1 = new TrafficLight("Red", 30);

        t1.display();
        t1.checkRed();
        t1.checkGreen();

        // Changing the color
        t1.changeColor("Green");

        System.out.println("\nAfter changing color:");

        t1.display();
        t1.checkRed();
        t1.checkGreen();
    }
}