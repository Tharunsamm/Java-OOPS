class Airplane {
    String flightNumber;
    String destination;
    String departureTime;
    boolean delayed;

    Airplane(String flightNumber, String destination, String departureTime) {
        this.flightNumber = flightNumber;
        this.destination = destination;
        this.departureTime = departureTime;
        this.delayed = false;
    }

    void delayFlight() {
        delayed = true;
    }

    void checkFlightStatus() {
        if (delayed) {
            System.out.println("Flight is delayed");
        } else {
            System.out.println("Flight is on time");
        }
    }

    void display() {
        System.out.println("Flight Number: " + flightNumber);
        System.out.println("Destination: " + destination);
        System.out.println("Departure Time: " + departureTime);
    }
}

public class q12 {
    public static void main(String[] args) {
        Airplane a1 = new Airplane("AA101", "New York", "10:30 AM");

        a1.display();
        a1.checkFlightStatus();

        a1.delayFlight();
        a1.checkFlightStatus();
    }
}