class BankAccount {
    double balance = 500;

    void deposit(double amount) {
        balance = balance + amount;
        System.out.println("Deposited: $" + amount);
        System.out.println("Balance: $" + balance);
    }

    void withdraw(double amount) {
        balance = balance - amount;
        System.out.println("Withdrawn: $" + amount);
        System.out.println("Balance: $" + balance);
    }
}

class SavingsAccount extends BankAccount {

    @Override
    void withdraw(double amount) {

        if (balance - amount >= 100) {
            balance = balance - amount;
            System.out.println("Withdrawn: $" + amount);
            System.out.println("Balance: $" + balance);
        } else {
            System.out.println("Withdrawal denied!");
            System.out.println("Balance cannot fall below $100.");
        }
    }
}

public class q5 {
    public static void main(String[] args) {

        SavingsAccount s = new SavingsAccount();

        s.deposit(200);
        s.withdraw(300);
        s.withdraw(350);
    }
}