import java.util.ArrayList;
import java.util.Random;

class MusicLibrary {
    ArrayList<String> songs = new ArrayList<>();

    void addSong(String song) {
        songs.add(song);
    }

    void removeSong(String song) {
        songs.remove(song);
    }

    void playRandomSong() {
        if (songs.size() > 0) {
            Random random = new Random();

            int index = random.nextInt(songs.size());

            System.out.println("Playing: " + songs.get(index));
        } else {
            System.out.println("No songs available");
        }
    }
}

public class q15 {
    public static void main(String[] args) {
        MusicLibrary music = new MusicLibrary();

        music.addSong("Song One");
        music.addSong("Song Two");
        music.addSong("Song Three");

        music.playRandomSong();
    }
}