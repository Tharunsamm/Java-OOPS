class Person{
    String getfirstName(){
        return "tharun";
    }
    String getlastName(){
        return "Sammeta";
    }
}
class Employee extends Person{
    String getEmployeeID(){
        return "12345";
    }
    @Override
    String getlastName(){
        return "Sammeta";
    }
    String getJobTitle(){
        return "Software Engineer";
    }
}
public class q7{
    public static void main(String[] args){
        Person p = new Person();
        Employee e = new Employee();
        System.out.println("First Name: " + p.getfirstName());
        System.out.println("Last Name: " + p.getlastName());
        System.out.println("Employee ID: " + e.getEmployeeID());
        System.out.println("Last Name: " + e.getlastName());
        System.out.println("Job Title: " + e.getJobTitle());
    }
}