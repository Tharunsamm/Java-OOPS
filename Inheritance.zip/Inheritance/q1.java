class Animal{
    void makeSound(){
        System.out.println("Animal makes a sound");
    }
}
class Dog extends Animal{
    void makeSound(){
        System.out.println("Dog barks");
    }
}
    public class q1{
        public static void main(String[] args){
            Animal a = new Animal();
            Dog d = new Dog();
            a.makeSound();
            d.makeSound();
        
    }
}