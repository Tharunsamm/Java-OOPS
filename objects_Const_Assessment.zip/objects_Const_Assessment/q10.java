import java.util.ArrayList;

class Student {
    String name;
    char grade;
    ArrayList<String> courses = new ArrayList<>();

    Student(String name, char grade) {
        this.name = name;
        this.grade = grade;
    }

    void addCourse(String course) {
        courses.add(course);
    }

    void removeCourse(String course) {
        courses.remove(course);
    }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Grade: " + grade);
        System.out.println("Courses: " + courses);
    }
}

public class q10 {
    public static void main(String[] args) {
        Student s1 = new Student("John", 'A');

        s1.addCourse("Java");
        s1.addCourse("SQL");

        s1.removeCourse("SQL");

        s1.display();
    }
}