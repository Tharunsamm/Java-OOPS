class Employee {

    String name;
    String jobTitle;
    double salary;

    // Constructor
    Employee(String name, String jobTitle, double salary) {
        this.name = name;
        this.jobTitle = jobTitle;
        this.salary = salary;
    }

    // Method to update salary
    void setSalary(double salary) {
        this.salary = salary;
    }

    // Method to calculate salary increase
    void calculateSalary(double percentage) {
        double increase = salary * percentage / 100;
        salary = salary + increase;
    }

    // Method to display employee details
    void display() {
        System.out.println("Name: " + name);
        System.out.println("Job Title: " + jobTitle);
        System.out.println("Salary: " + salary);
    }
}

public class q6 {
    public static void main(String[] args) {

        // Creating Employee object
        Employee e1 = new Employee(
            "John",
            "Software Developer",
            60000
        );

        // Display original salary
        System.out.println("Original Details:");
        e1.display();

        // Calculate 10% salary increase
        e1.calculateSalary(10);

        System.out.println("\nAfter 10% Increase:");
        e1.display();

        // Update salary directly using setter
        e1.setSalary(70000);

        System.out.println("\nAfter Updating Salary:");
        e1.display();
    }
}