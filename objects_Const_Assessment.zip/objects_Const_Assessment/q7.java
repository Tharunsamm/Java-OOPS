import java.util.ArrayList;

class Account {

    String customerName;
    int accountNumber;
    double balance;

    // Constructor
    Account(String customerName, int accountNumber, double balance) {
        this.customerName = customerName;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Deposit money
    void deposit(double amount) {
        balance = balance + amount;
    }

    // Withdraw money
    void withdraw(double amount) {
        if (amount <= balance) {
            balance = balance - amount;
        } else {
            System.out.println("Insufficient balance");
        }
    }

    // Display account details
    void display() {
        System.out.println("Customer Name: " + customerName);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: $" + balance);
    }
}


class Bank {

    ArrayList<Account> accounts = new ArrayList<>();

    // Add account
    void addAccount(Account account) {
        accounts.add(account);
    }

    // Remove account
    void removeAccount(Account account) {
        accounts.remove(account);
    }

    // Display all accounts
    void displayAccounts() {
        for (Account account : accounts) {
            account.display();
            System.out.println();
        }
    }
}


public class q7 {

    public static void main(String[] args) {

        // Create Bank object
        Bank bank = new Bank();

        // Create Account objects
        Account a1 = new Account("John", 101, 5000);
        Account a2 = new Account("David", 102, 3000);

        // Add accounts to bank
        bank.addAccount(a1);
        bank.addAccount(a2);

        // Deposit money
        a1.deposit(1000);

        // Withdraw money
        a2.withdraw(500);

        // Display accounts
        bank.displayAccounts();

        // Remove an account
        bank.removeAccount(a2);
    }
}