import java.util.ArrayList;

class Product {
    String name;
    int quantity;

    Product(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }
}

class Inventory {
    ArrayList<Product> products = new ArrayList<>();

    void addProduct(Product product) {
        products.add(product);
    }

    void removeProduct(Product product) {
        products.remove(product);
    }

    void checkLowInventory() {
        for (Product product : products) {
            if (product.quantity < 5) {
                System.out.println(product.name + " has low inventory");
            }
        }
    }
}

public class q13 {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        Product p1 = new Product("Laptop", 10);
        Product p2 = new Product("Mouse", 3);

        inventory.addProduct(p1);
        inventory.addProduct(p2);

        inventory.checkLowInventory();
    }
}